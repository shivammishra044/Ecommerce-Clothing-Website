<?php
$con = mysqli_connect("localhost","root", "", "threaderz_store");
?>